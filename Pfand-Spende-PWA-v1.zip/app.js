const screens = ["home","find","give","request","account"];
let offers = JSON.parse(localStorage.getItem("pfand-spende-offers") || "[]");
let selectedOffer = null;

function showScreen(id){
  screens.forEach(s => document.getElementById(s)?.classList.toggle("active", s===id));
  window.scrollTo({top:0, behavior:"smooth"});
  if(id==="find") renderOffers();
}
function toggleMenu(){document.getElementById("menu").classList.toggle("hidden")}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2800)}

function renderOffers(){
  const box=document.getElementById("markers"), empty=document.getElementById("emptyState");
  box.innerHTML="";
  if(!offers.length){empty.style.display="block";return}
  empty.style.display="none";
  offers.forEach((o,i)=>{
    const m=document.createElement("button");
    m.className="marker"; m.style.left=(18+(i*27)%68)+"%"; m.style.top=(32+(i*41)%48)+"%";
    m.title="Pfand-Angebot"; m.innerHTML="<span>"+(o.types.includes("Dosen")?"🥫":"🍾")+"</span>";
    m.onclick=()=>openOffer(o);
    box.appendChild(m);
  });
}
function openOffer(o){
  selectedOffer=o;
  document.getElementById("requestSummary").innerHTML=
    `<b>${o.types.join(" & ")}</b><p>📍 Ungefährer Bereich · ca. 200 m Radius</p>
     <p>${o.description || "Abholung nach Absprache."}</p>
     <small>Die genaue Adresse wird erst nach Bestätigung durch den Spender freigegeben.</small>`;
  showScreen("request");
}
document.getElementById("giveForm").addEventListener("submit",e=>{
  e.preventDefault();
  const types=[];
  if(e.target.bottle.checked) types.push("Flaschen");
  if(e.target.can.checked) types.push("Dosen");
  if(!types.length){toast("Bitte Flaschen oder Dosen auswählen.");return}
  const offer={id:Date.now(),types,address:e.target.address.value,description:e.target.description.value,created:new Date().toISOString()};
  offers.push(offer);localStorage.setItem("pfand-spende-offers",JSON.stringify(offers));
  e.target.reset();e.target.bottle.checked=true;
  toast("Pfand-Angebot wurde erstellt. Der genaue Standort bleibt geschützt.");
  showScreen("find");
});
document.getElementById("requestForm").addEventListener("submit",e=>{
  e.preventDefault();
  toast("Abholanfrage wurde gesendet. In der echten App erhält der Spender eine Nachricht.");
  showScreen("find");
});
function demoAccount(){
  toast("Demo-Konto gespeichert. Die echte Version bekommt sichere Anmeldung.");
}
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
renderOffers();