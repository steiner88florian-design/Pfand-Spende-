# Pfand Spende – PWA Prototyp

Dies ist Version 1 des visuellen/technischen Prototyps.

## Testen
index.html kann lokal geöffnet werden. Für die PWA-Installation muss die App über HTTPS ausgeliefert werden.

## Wichtig
Diese Version ist absichtlich ein Frontend-Prototyp:
- Angebote werden lokal im Browser gespeichert.
- Es gibt noch keine echte Benutzerverwaltung.
- Es gibt noch keine gemeinsame Online-Datenbank.
- Die Karte ist eine Prototyp-Kartenfläche und noch keine echte Deutschland/Österreich-Karte.
- Die 200-m-Schutzlogik ist im UI beschrieben, aber noch nicht serverseitig durchgesetzt.

## Nächster Entwicklungsschritt
Für eine echte App:
1. OpenStreetMap/MapLibre-Karte
2. Supabase-Datenbank
3. sichere Authentifizierung
4. serverseitige Standortverschleierung
5. Abholanfragen und Freigaben
6. private Nachrichten
7. Fotospeicher
8. Missbrauch melden / Moderation
9. Datenschutz / DSGVO
10. PWA-Deployment und später App Store / Play Store
